package com.TAE.tests;

import com.TAE.base.TestBase;
import com.TAE.pages.HomePage;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class HomePageTest extends TestBase {

   // @BeforeTest
    HomePage homePage;

    public HomePageTest() {
       WebDriver driver = TestBase.initializeBrowser();

        homePage = new HomePage(driver);
    }

    @Test
    public void openHomePage(){
homePage.validateHomePageTitle();
    }


}
