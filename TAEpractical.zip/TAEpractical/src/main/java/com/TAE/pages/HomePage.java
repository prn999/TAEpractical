package com.TAE.pages;

import com.TAE.base.TestBase;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class HomePage extends TestBase  {

  //  public HomePage(WebDriver driver){
//driver = this.driver;    }

    public WebElement startShoppingTab = driver.findElement(By.xpath("//a[@class = 'btn btn-success btn-large']"));

     public String validateHomePageTitle() {
        return driver.getTitle();
    }
}
